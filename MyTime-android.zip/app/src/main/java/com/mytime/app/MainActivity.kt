package com.mytime.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class Pal(
    val bg: Color,
    val card: Color,
    val ink: Color,
    val soft: Color,
    val primary: Color,
    val onPrimary: Color,
    val warn: Color,
    val line: Color
)

private val LightPal = Pal(
    bg = Color(0xFFF2F5F7), card = Color.White, ink = Color(0xFF17262E), soft = Color(0xFF63757F),
    primary = Color(0xFF14606B), onPrimary = Color.White, warn = Color(0xFFB4600A), line = Color(0xFFDCE3E8)
)
private val DarkPal = Pal(
    bg = Color(0xFF0F1A1F), card = Color(0xFF18262D), ink = Color(0xFFE5EEF2), soft = Color(0xFF93A6B0),
    primary = Color(0xFF4FB3C1), onPrimary = Color(0xFF06181C), warn = Color(0xFFF0B36A), line = Color(0xFF28383F)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Reminders.ensureChannel(this)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App(if (dark) DarkPal else LightPal)
                }
            }
        }
    }
}

@Composable
private fun App(pal: Pal) {
    val ctx = LocalContext.current
    val tasks = remember { mutableStateListOf<Task>().apply { addAll(Store.load(ctx)) } }
    var folder by remember { mutableStateOf<String?>(null) }
    var showText by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    fun persist() {
        Store.save(ctx, tasks.toList())
    }

    fun add(text: String) {
        val p = Parser.parse(text)
        val t = Task(System.currentTimeMillis(), text.trim(), p.folder, p.due, false)
        tasks.add(0, t)
        persist()
        Reminders.schedule(ctx, t)
        val extra = if (t.due != null) " و یادآوری تنظیم شد" else ""
        Toast.makeText(ctx, "در «${t.folder}» ذخیره شد$extra", Toast.LENGTH_SHORT).show()
    }

    fun toggle(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = tasks[i].copy(done = !tasks[i].done)
        tasks[i] = t
        if (t.done) Reminders.cancel(ctx, t) else Reminders.schedule(ctx, t)
        persist()
    }

    fun remove(id: Long) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        Reminders.cancel(ctx, tasks[i])
        tasks.removeAt(i)
        persist()
    }

    fun move(id: Long, to: String) {
        val i = tasks.indexOfFirst { it.id == id }
        if (i < 0) return
        val t = tasks[i].copy(folder = to)
        tasks[i] = t
        Reminders.schedule(ctx, t)
        persist()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) add(spoken)
        }
    }

    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "کارت را بگو")
        }
        try {
            speech.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "تشخیص گفتار روی این گوشی نیست. از دکمهٔ نوشتن استفاده کنید.", Toast.LENGTH_LONG).show()
        }
    }

    val shown = tasks
        .filter { folder == null || it.folder == folder }
        .sortedWith(compareBy<Task>({ it.done }, { it.due ?: Long.MAX_VALUE }))
    val openCount = tasks.count { !it.done }

    Column(Modifier.fillMaxSize().background(pal.bg).systemBarsPadding()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            Text("مدیریت زمان من", color = pal.ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                if (openCount == 0) "کار بازی ندارید" else "${Fmt.digits(openCount)} کار باز",
                color = pal.soft,
                fontSize = 14.sp
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FolderChip("همه", openCount, folder == null, pal) { folder = null }
            }
            items(Parser.folders) { f ->
                FolderChip(f, tasks.count { it.folder == f && !it.done }, folder == f, pal) { folder = f }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 20.dp, top = 14.dp, end = 20.dp, bottom = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (shown.isEmpty()) {
                item {
                    Text(
                        "دکمهٔ وسط را بزنید و کارتان را بگویید. خودم دسته‌بندی و یادآوری‌اش می‌کنم.",
                        color = pal.soft,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 24.dp, end = 24.dp)
                    )
                }
            }
            items(shown, key = { it.id }) { t ->
                TaskCard(
                    t = t,
                    now = now,
                    pal = pal,
                    onToggle = { toggle(t.id) },
                    onDelete = { remove(t.id) },
                    onMove = { move(t.id, it) }
                )
            }
        }

        Box(
            Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(116.dp).clip(CircleShape).background(pal.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(88.dp).clip(CircleShape).background(pal.primary).clickable { listen() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Mic,
                        contentDescription = "گفتن کار",
                        tint = pal.onPrimary,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }
            IconButton(
                onClick = { showText = true },
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 20.dp)
            ) {
                Icon(Icons.Filled.Keyboard, contentDescription = "نوشتن کار", tint = pal.soft)
            }
        }
    }

    if (showText) {
        TextDialog(
            onDismiss = { showText = false },
            onSave = {
                showText = false
                add(it)
            }
        )
    }
}

@Composable
private fun FolderChip(name: String, count: Int, selected: Boolean, pal: Pal, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) pal.primary else pal.card)
            .border(1.dp, if (selected) pal.primary else pal.line, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            "$name  ${Fmt.digits(count)}",
            color = if (selected) pal.onPrimary else pal.ink,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun TaskCard(
    t: Task,
    now: Long,
    pal: Pal,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onMove: (String) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val due = t.due
    val overdue = !t.done && due != null && due <= now
    val shape = RoundedCornerShape(16.dp)

    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (t.done) 0.55f else 1f)
            .clip(shape)
            .background(pal.card)
            .border(1.dp, pal.line, shape)
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier
                .padding(top = 2.dp)
                .size(26.dp)
                .clip(CircleShape)
                .background(if (t.done) pal.primary else Color.Transparent)
                .border(2.dp, if (t.done) pal.primary else pal.soft, CircleShape)
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (t.done) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = pal.onPrimary, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.text,
                color = pal.ink,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                textDecoration = if (t.done) TextDecoration.LineThrough else null
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    Text(
                        t.folder,
                        color = pal.soft,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(pal.bg)
                            .clickable { menu = true }
                            .padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        Parser.folders.forEach { f ->
                            DropdownMenuItem(
                                text = { Text(f) },
                                onClick = {
                                    menu = false
                                    onMove(f)
                                }
                            )
                        }
                    }
                }
                if (due != null) {
                    Text(
                        Fmt.due(due),
                        color = if (overdue) pal.warn else pal.soft,
                        fontSize = 13.sp,
                        fontWeight = if (overdue) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = pal.soft)
        }
    }
}

@Composable
private fun TextDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("کار جدید") },
        text = {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("مثلاً: فردا ساعت ۱۰ جلسه") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (input.isNotBlank()) onSave(input) }) { Text("ثبت") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    )
}
