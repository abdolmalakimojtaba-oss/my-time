package com.mytime.app

import java.util.Calendar

data class Parsed(val folder: String, val due: Long?)

object Parser {

    val folders = listOf("معاملات", "کاری", "خرید", "سلامت", "شخصی", "سایر")

    private val rules = listOf(
        "معاملات" to listOf("معامله", "فارکس", "طلا", "اکسپرت", "استاپ", "سیگنال", "ترید", "بروکر", "نیویورک", "xau"),
        "سلامت" to listOf("دکتر", "دارو", "ورزش", "باشگاه", "پزشک", "آزمایش", "نوبت", "قرص", "دندان"),
        "خرید" to listOf("بخر", "خرید", "سوپر", "میوه", "نان", "نون", "فروشگاه", "سفارش"),
        "کاری" to listOf("جلسه", "گزارش", "پروژه", "ایمیل", "مشتری", "قرارداد", "تحویل", "کارفرما"),
        "شخصی" to listOf("مادر", "پدر", "دوست", "تولد", "خانواده", "همسر", "بچه", "تماس", "زنگ", "قبض", "بیمه")
    )

    private val words = mapOf(
        "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6,
        "هفت" to 7, "هشت" to 8, "نه" to 9, "ده" to 10, "یازده" to 11, "دوازده" to 12
    )

    private const val NUM = "(\\d{1,2}|دوازده|یازده|چهار|پنج|شش|هفت|هشت|یک|دو|سه|نه|ده)"

    fun parse(raw: String): Parsed {
        val t = norm(raw)
        val folder = rules.firstOrNull { (_, keys) -> keys.any { t.contains(it) } }?.first ?: "سایر"
        return Parsed(folder, due(t))
    }

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            sb.append(
                when (c) {
                    in '۰'..'۹' -> '0' + (c - '۰')
                    in '٠'..'٩' -> '0' + (c - '٠')
                    '\u200c' -> ' '
                    'ي' -> 'ی'
                    'ك' -> 'ک'
                    else -> c
                }
            )
        }
        return sb.toString().lowercase()
    }

    private fun num(s: String): Int? = s.toIntOrNull() ?: words[s]

    private fun due(t: String): Long? {
        // 1) relative: "۲ ساعت دیگه", "۳۰ دقیقه بعد", "نیم ساعت دیگه"
        val rel = Regex("$NUM\\s*(دقیقه|ساعت)\\s*(دیگه|دیگر|بعد)").find(t)
        if (rel != null) {
            val n = num(rel.groupValues[1])
            if (n != null) {
                val c = Calendar.getInstance()
                if (rel.groupValues[2] == "دقیقه") c.add(Calendar.MINUTE, n)
                else c.add(Calendar.HOUR_OF_DAY, n)
                return c.timeInMillis
            }
        }
        if (Regex("نیم ساعت\\s*(دیگه|دیگر|بعد)").containsMatchIn(t)) {
            val c = Calendar.getInstance()
            c.add(Calendar.MINUTE, 30)
            return c.timeInMillis
        }

        // 2) day word
        val tonight = t.contains("امشب")
        val day: Int? = when {
            t.contains("پس فردا") || t.contains("پسفردا") -> 2
            t.contains("فردا") -> 1
            t.contains("امروز") || tonight -> 0
            else -> null
        }

        // 3) clock time
        var hour: Int? = null
        var min = 0
        var endIdx = -1
        val m = Regex("ساعت\\s*$NUM(?::(\\d{2}))?").find(t)
        if (m != null) {
            hour = num(m.groupValues[1])
            m.groupValues[2].toIntOrNull()?.let { min = it }
            endIdx = m.range.last + 1
        } else {
            val m2 = Regex("(\\d{1,2}):(\\d{2})").find(t)
            if (m2 != null) {
                hour = m2.groupValues[1].toInt()
                min = m2.groupValues[2].toInt()
                endIdx = m2.range.last + 1
            }
        }
        if (endIdx in 0..t.length) {
            val tail = t.substring(endIdx)
            val mm = Regex("^\\s*و\\s*(نیم|ربع|(\\d{1,2})\\s*دقیقه)").find(tail)
            if (mm != null) {
                min = when (mm.groupValues[1]) {
                    "نیم" -> 30
                    "ربع" -> 15
                    else -> mm.groupValues[2].toIntOrNull() ?: 0
                }
            }
        }

        // 4) part of day
        val hasPm = listOf("عصر", "بعد از ظهر", "بعدازظهر", "شب", "امشب").any { t.contains(it) }
        val hasNoon = t.contains("ظهر") && !t.contains("بعد از ظهر") && !t.contains("بعدازظهر")
        val hasAm = t.contains("صبح")
        val hasPeriod = hasPm || hasNoon || hasAm

        var h = hour
        if (h != null) {
            if (hasNoon && h in 1..5) h += 12
            else if (hasPm && h in 1..11) h += 12
            else if (hasPm && h == 12 && t.contains("شب")) h = 0
            else if (hasAm && h == 12) h = 0
        }

        if (h == null && day == null) return null
        if (h != null && (h > 23 || min > 59)) return null

        val now = System.currentTimeMillis()
        val finalHour = h ?: if (tonight) 20 else 9
        val finalMin = if (h == null) 0 else min

        val c = Calendar.getInstance()
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.set(Calendar.HOUR_OF_DAY, finalHour)
        c.set(Calendar.MINUTE, finalMin)
        if (day != null) {
            c.add(Calendar.DAY_OF_YEAR, day)
        } else if (c.timeInMillis <= now) {
            if (!hasPeriod && finalHour < 12 && c.timeInMillis + 12 * 3600_000L > now) {
                c.add(Calendar.HOUR_OF_DAY, 12)
            } else {
                c.add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        return c.timeInMillis
    }
}
