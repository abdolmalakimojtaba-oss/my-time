package com.mytime.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Task(
    val id: Long,
    val text: String,
    val folder: String,
    val due: Long?,
    val done: Boolean
)

object Store {
    private fun file(ctx: Context) = File(ctx.filesDir, "tasks.json")

    fun load(ctx: Context): List<Task> {
        return try {
            val f = file(ctx)
            if (!f.exists()) {
                emptyList()
            } else {
                val arr = JSONArray(f.readText())
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    Task(
                        id = o.getLong("id"),
                        text = o.getString("text"),
                        folder = o.getString("folder"),
                        due = if (o.isNull("due")) null else o.getLong("due"),
                        done = o.getBoolean("done")
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Task>) {
        try {
            val arr = JSONArray()
            list.forEach { t ->
                arr.put(
                    JSONObject()
                        .put("id", t.id)
                        .put("text", t.text)
                        .put("folder", t.folder)
                        .put("due", t.due ?: JSONObject.NULL)
                        .put("done", t.done)
                )
            }
            file(ctx).writeText(arr.toString())
        } catch (e: Exception) {
            // ignore write errors; next save will retry
        }
    }
}

object Fmt {
    private val formatter = android.icu.text.SimpleDateFormat(
        "EEEE d MMMM، HH:mm",
        android.icu.util.ULocale("fa_IR@calendar=persian")
    )

    fun due(ms: Long): String = formatter.format(java.util.Date(ms))

    fun digits(n: Int): String =
        n.toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
}
